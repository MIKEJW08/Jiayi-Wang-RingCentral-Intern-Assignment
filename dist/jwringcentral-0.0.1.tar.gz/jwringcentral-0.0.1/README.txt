# Foobar

PyPac is a Python package created by Jiayi(Mike) Wang and is for the RingCentral Data Analytics & Engineering Summer Internship. 

## Installation

Install using pip
```
pip install PyPac
```

## Usage

```python
import PyPac


```

## Requirements
* Python 3
* Numpy
* Pandas

## License
[MIT](https://choosealicense.com/licenses/mit/)